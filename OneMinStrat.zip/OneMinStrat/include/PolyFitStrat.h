#ifndef PROJECT_POLYFITSTRAT_H
#define PROJECT_POLYFITSTRAT_H

#include "MA.h"
#include "MinuteStrat.h"

class PolyFitStrat : public MinuteStrat {
public:
  PolyFitStrat();

private:
  int onDayChange(RangeStat &RangeData, RangeStat &lastRangeData);

  int onEndTime(RangeStat &RangeData, RangeStat &lastRangeData);

  int onRange(RangeStat &RangeData);

  int onTrigger();

  int onTriggerTime(std::vector<double> &der, std::vector<double> &cof,
                    RangeStat &range);

  int afterTriggerTime(std::vector<double> &der, RangeStat &range);

  int onTriggerTimeNeg(std::vector<double> &der, std::vector<double> &cof,
                       RangeStat &range);

  int afterTriggerTimeNeg(std::vector<double> &der, RangeStat &range);

/*  int onTriggerTimeFirstOrderOnly(std::vector<double> &der,
                                  std::vector<double> &cof,
                                  RangeStat &range);

  int afterTriggerTimeFirstOrderOnly(std::vector<double> &cof,
                                                   RangeStat &range);

  int onRangeTimeMAFlat(RangeStat &range, double ma);*/

  std::vector<double> fittingVec;
  std::vector<unsigned long> fittingVecTime;

  std::string stratDir;
  std::string firstOrderOnly;
  std::string flatMethod;

  int maxLotSize;
  int holding;

  double der0Threshold;
  double der1Threshold;

  std::vector<double> firstOrderList;
  std::vector<double> secondOrderList;

  MA ma60;

};


#endif //PROJECT_POLYFITSTRAT_H
