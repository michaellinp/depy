#ifndef TOBAR
#define TOBAR


#include <algorithm>
#include <boost/date_time/posix_time/posix_time.hpp>
#include <boost/date_time/gregorian/gregorian.hpp>
#include "Backtester.h"
#include "CedarTimeHelper.h"
#include "CPlusPlusCode/ProtoBufMsg.pb.h"
#include "EnumStringMap.h"
#include "JsonHelper.h"
#include "MarketSpecHelper.h"

namespace pt = boost::posix_time;
namespace gg = boost::gregorian;

class Tobar {
public:
  Tobar();
  Tobar(int seconds);
  int getTick(MarketUpdate &mkt, RangeStat &rangeST);
private:
  double high;
  double low;
  double open;
  double close;

  pt::ptime start;
  pt::ptime end;
  int initFlag;

  int seconds;
  pt::time_duration interval;

  boost::posix_time::ptime ripTimeResidualSec(boost::posix_time::ptime time);

};



#endif //PROJECT_TOBAR_H
