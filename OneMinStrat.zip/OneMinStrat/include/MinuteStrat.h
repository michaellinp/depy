#ifndef POLYFITSTRATS_H
#define POLYFITSTRATS_H

#include <CPlusPlusCode/ProtoBufMsg.pb.h>
#include "StratBase.h"
#include "RangeStatCollector.h"
#include "Tobar.h"
#include "PolyFit.h"
#include "CedarTimeHelper.h"
#include "time.h"

class MinuteStrat : public StratBase {
public:
  MinuteStrat();

  ~MinuteStrat() {
    onExit();
  };

  int onMsg(MessageBase &msg);

  Json::Value config;
  int activeSig;

  // boost::posix_time::ptime getCurrentTimeFromRange(RangeStat &range);
  boost::posix_time::ptime getDayTimeFromRange(RangeStat &range);

  std::vector<RangeStat> DataHistory;
  std::string unixTimeToStr(unsigned long unix);
private:
  int onCreate();

  int onExit();

  int onRangeStatUpdate(RangeStat &);

  virtual int onDayChange(RangeStat &RangeData, RangeStat &lastRangeData) = 0;

  virtual int onRange(RangeStat &RangeData) = 0;

  virtual int onEndTime(RangeStat &RangeData, RangeStat &lastRangeData) = 0;

  virtual int onTrigger() = 0;


  RangeCollector oneMinData;
  std::string respAddr;

  std::string dayStartTimeStr;
  std::string dayEndTimeStr;
  std::string triggerTimeStr;

  std::string mode;

  static constexpr int memoryLength = 120;


};


#endif