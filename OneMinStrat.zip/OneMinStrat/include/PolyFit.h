#ifndef POLYFIT_H
#define POLYFIT_H

#include <vector>
#include <gsl_multifit.h>

std::vector<double>
polyFit(std::vector<double> X, std::vector<double> y, unsigned int order);

std::vector<double> getDerivatives(std::vector<double> X, std::vector<double> y,
                                   unsigned int order);

#endif
