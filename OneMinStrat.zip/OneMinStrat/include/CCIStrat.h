//
// Created by mwan on 17-3-3.
//

#ifndef CCI_H
#define CCI_H


#include "OneMinStrat.h"
#include "CCI.h"

class CCIStrat: public OneMinStrat {
public:
  CCIStrat();
private:
  int onDayChange(RangeStat &RangeData, RangeStat &lastRangeData);
  int onEndTime(RangeStat &RangeData, RangeStat &lastRangeData);
  int onRange(RangeStat &RangeData);
  int onTrigger();

  int onTriggerTime(std::vector<double> &der, std::vector<double> &cof, RangeStat &range) ;
  int afterTriggerTime(std::vector<double> &der, RangeStat &range);
  int onTriggerTimeNeg(std::vector<double> &der, std::vector<double> &cof, RangeStat &range) ;
  int afterTriggerTimeNeg(std::vector<double> &der, RangeStat &range);

  std::vector<double> fittingVec;
  std::vector<unsigned long> fittingVecTime;

  std::string stratDir;
  int holding;

  double der0Threshold;
  double der1Threshold;

  CCI CCIIndicator;
};


#endif //PROJECT_POLYFITSTRAT_H
