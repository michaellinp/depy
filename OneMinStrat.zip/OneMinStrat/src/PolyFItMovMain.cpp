#include "PolyFItMov.h"
#include "CedarHelper.h"

int main(int argc, char *argv[]) {
  LOG(INFO) << "MOV!";
  CedarHelper::cedarAppInit(argc, argv);

  PolyFItMov pfs;
  pfs.run();


  google::protobuf::ShutdownProtobufLibrary();

}