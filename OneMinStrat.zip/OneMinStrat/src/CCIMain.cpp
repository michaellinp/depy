#include "CCIStrat.h"
#include "CedarHelper.h"

int main(int argc, char *argv[]) {
  CedarHelper::cedarAppInit(argc, argv);

  CCIStrat pfs;
  pfs.run();


  google::protobuf::ShutdownProtobufLibrary();

}