#include "OneMinStrat.h"
#include "CedarHelper.h"

int main(int argc, char *argv[]) {
  CedarHelper::cedarAppInit(argc, argv);

  OneMinStrat pfs;
  pfs.run();


  google::protobuf::ShutdownProtobufLibrary();

}