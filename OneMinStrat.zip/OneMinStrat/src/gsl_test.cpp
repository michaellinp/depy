#include <iostream>
#include "PolyFit.h"
int main() {

  std::vector<double> X;
  std::vector<double> Y;

  for (int i = 0; i < 10; i++) {
    X.push_back(i);
    Y.push_back(3 * i * i + 9.066 * i + 8);
  }

  std::vector<double> result = polyFit(X, Y, 3);
  for (auto iter = result.begin(); iter != result.end(); iter++) {
    std::cout << *iter << std::endl;
  }

  return 0;
}



