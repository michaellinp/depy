#include "PolyFitStrat.h"

PolyFitStrat::PolyFitStrat() : ma60(1 / 60.0) {
  stratDir = config["Direction"].asString();
  firstOrderOnly = config["FirstOrderOnly"].asString();
  flatMethod = config["FlatMethod"].asString();

  CedarJsonConfig::getInstance().getIntByPath("RiskConfig.MaxLotSize", maxLotSize);
  LOG(INFO) << "maxLotSize:" << maxLotSize;
}

int PolyFitStrat::onDayChange(RangeStat &RangeData, RangeStat &lastRangeData) {
  flatAllPosition(lastRangeData.code(), lastRangeData.close(),
                  lastRangeData.end_timestamp_string());
  fittingVec.clear();
  fittingVecTime.clear();
  activeSig = 1;
  holding = 0;
  return 0;
}

int PolyFitStrat::onEndTime(RangeStat &RangeData, RangeStat &lastRangeData) {
  flatAllPosition(lastRangeData.code(), lastRangeData.close(),
                  lastRangeData.end_timestamp_string());
  fittingVec.clear();
  fittingVecTime.clear();
  return 0;
}

int PolyFitStrat::onRange(RangeStat &RangeData) {

  //LOG(INFO) << "range:" << RangeData.DebugString();
 // double ma = ma60.update(RangeData.close());
  fittingVec.push_back(RangeData.close());
  fittingVecTime.push_back(RangeData.unix_timestamp());

  if (activeSig == 0) {

    if (fittingVec.size() < 10) {
      return 0;
    }

    std::vector<double> X;
    for (unsigned i = 0; i < fittingVec.size(); i++) {
      X.push_back(i);
    }

    std::vector<double> der = getDerivatives(X, fittingVec, 3);
    std::vector<double> cof = polyFit(X, fittingVec, 3);

/*    if (flatMethod == "MA") {
      onRangeTimeMAFlat(RangeData, ma);
    } else if (firstOrderOnly == "YES") {
      afterTriggerTimeFirstOrderOnly(cof, RangeData);
    } else if (stratDir == "POSITIVE") {
      afterTriggerTime(der, RangeData);
    } else if (stratDir == "NEGTIVE") {
      afterTriggerTimeNeg(der, RangeData);
    } else {
      LOG(FATAL) << "stat direction not known plz check!";
    }*/

    if (stratDir == "POSITIVE") {
      afterTriggerTime(der, RangeData);
    } else if (stratDir == "NEGTIVE") {
      afterTriggerTimeNeg(der, RangeData);
    } else {
      LOG(FATAL) << "stat direction not known plz check!";
    }
  }

  return 0;
}


int PolyFitStrat::onTrigger() {
  if (fittingVec.size() < 10) {
    return 0;
  }

  std::vector<double> X;
  for (unsigned i = 0; i < fittingVec.size(); i++) {
    X.push_back(i);
  }

  std::vector<double> der = getDerivatives(X, fittingVec, 3);
  std::vector<double> cof = polyFit(X, fittingVec, 3);

  RangeStat lastRangeData = DataHistory.back();

/*  if (firstOrderOnly == "NO") {
    if (stratDir == "POSITIVE") {
      onTriggerTime(der, cof, lastRangeData);
    } else if (stratDir == "NEGTIVE") {
      onTriggerTimeNeg(der, cof, lastRangeData);
    }
  } else if (firstOrderOnly == "YES") {
      onTriggerTimeFirstOrderOnly(der, cof, lastRangeData);
  }*/

  if (stratDir == "POSITIVE") {
    onTriggerTime(der, cof, lastRangeData);
  } else if (stratDir == "NEGTIVE") {
    onTriggerTimeNeg(der, cof, lastRangeData);
  }

  activeSig = 0;
  return 0;
}


////////////////////////////////////////////////////////////////////////////////
/*int PolyFitStrat::onTriggerTimeFirstOrderOnly(std::vector<double> &der,
                                              std::vector<double> &cof,
                                              RangeStat &range) {


  std::string timeStr = unixTimeToStr(range.unix_timestamp());

  if (cof[1] < 0) {
    limitPositionAlg(1, SHORT_SELL,
                     range.code(), 1, range.close(),
                     timeStr);
    holding = -1;
  } else if (cof[1] > 0) {
    limitPositionAlg(1, LONG_BUY,
                     range.code(), 1, range.close(),
                     timeStr);
    holding = 1;
  } else {
    flatAllPosition(range.code(), range.close(), range.end_timestamp_string());
  }

  return 0;
}*/

/*int PolyFitStrat::afterTriggerTimeFirstOrderOnly(std::vector<double> &cof,
                                                 RangeStat &range) {
  // LOG(INFO) << "test der0:" << der[0] << "," << ",der1:"
  //            << der[1];

  std::string timeStr = unixTimeToStr(range.unix_timestamp());

  if (cof[1] < 0 && holding == 1) {
    flatAllPosition(range.code(), range.close(), timeStr);
    holding = 0;
  } else if (cof[1] > 0 && holding == -1) {
    flatAllPosition(range.code(), range.close(), timeStr);

    holding = 0;
  }
  //  LOG(INFO) << range.timestamp();
  std::string hmsTimestamp = timeStr;
  if (MarketSpecHelper::isNearMktClose(
      const_cast<std::string &>(range.code()),
      const_cast<std::string &>(hmsTimestamp))) {
    flatAllPosition(range.code(), range.close(), timeStr);
    LOG(INFO) << "<<<" << "FLAT:[" << range.close() << "]>>>";
  }
  return 0;
}*/


/*int PolyFitStrat::onRangeTimeMAFlat(RangeStat &range, double ma) {
  std::string timeStr = unixTimeToStr(range.unix_timestamp());

  if (holding > 0 && ma > range.close()) {
    flatAllPosition(range.code(), range.close(), timeStr);
  } else if (holding < 0 && ma < range.close()) {
    flatAllPosition(range.code(), range.close(), timeStr);
  }

  return 0;
}*/

int PolyFitStrat::onTriggerTimeNeg(std::vector<double> &der,
                                   std::vector<double> &cof,
                                   RangeStat &range) {
  std::string timeStr = unixTimeToStr(range.unix_timestamp());

  if (der[0] > 0 && der[1] > 0) {
    limitPositionAlg(maxLotSize, SHORT_SELL, range.code(), maxLotSize, range.close(), timeStr);
    holding = -1;
  } else if (der[0] < 0 && der[1] < 0) {
    limitPositionAlg(maxLotSize, LONG_BUY, range.code(), maxLotSize, range.close(), timeStr);
    holding = 1;
  } else {
    flatAllPosition(range.code(), range.close(), range.end_timestamp_string());
  }

  return 0;
}

int PolyFitStrat::onTriggerTime(std::vector<double> &der,
                                std::vector<double> &cof, RangeStat &range) {
  std::string timeStr = unixTimeToStr(range.unix_timestamp());

  if (der[0] > 0 && der[1] > 0) {
    limitPositionAlg(maxLotSize, LONG_BUY, range.code(), maxLotSize, range.close(), timeStr);
    holding = 1;
  } else if (der[0] < 0 && der[1] < 0) {
    limitPositionAlg(maxLotSize, SHORT_SELL, range.code(), maxLotSize, range.close(), timeStr);
    holding = -1;
  }

  return 0;
}

int PolyFitStrat::afterTriggerTime(std::vector<double> &der,
                                   RangeStat &range) {
  std::string timeStr = unixTimeToStr(range.unix_timestamp());

  if ((der[0] > 0 || der[1] > 0) && holding == -1) {
    flatAllPosition(range.code(), range.close(), timeStr);
    holding = 0;
  } else if ((der[0] < 0 || der[1] < 0) && holding == 1) {
    flatAllPosition(range.code(), range.close(), timeStr);
    holding = 0;
  }
  //  LOG(INFO) << range.timestamp();
  std::string hmsTimestamp = timeStr;
  if (MarketSpecHelper::isNearMktClose(
      const_cast<std::string &>(range.code()),
      const_cast<std::string &>(hmsTimestamp))) {
    flatAllPosition(range.code(), range.close(), timeStr);
  }
  return 0;
}

int PolyFitStrat::afterTriggerTimeNeg(std::vector<double> &der,
                                      RangeStat &range) {
  std::string timeStr = unixTimeToStr(range.unix_timestamp());

  if ((der[0] > 0 || der[1] > 0) && holding == 1) {
    flatAllPosition(range.code(), range.close(), timeStr);
    holding = 0;
  } else if ((der[0] < 0 || der[1] < 0) && holding == -1) {
    flatAllPosition(range.code(), range.close(), timeStr);
    holding = 0;
  }
  std::string hmsTimestamp = timeStr;
  if (MarketSpecHelper::isNearMktClose(
      const_cast<std::string &>(range.code()),
      const_cast<std::string &>(hmsTimestamp))) {
    flatAllPosition(range.code(), range.close(), timeStr);
  }
  return 0;
}


