//
// Created by mwan on 17-3-4.
//

#include "PolyFItMov.h"


PolyFItMov::PolyFItMov() {
  stratDir = config["Direction"].asString();
  refreshCount = 0;
  WindowLength = config["WindowLength"].asInt();
  Interval = config["Interval"].asInt();
}

int PolyFItMov::onDayChange(RangeStat &RangeData, RangeStat &lastRangeData) {
  flatAll(lastRangeData.code(), lastRangeData.close(),
          lastRangeData.end_timestamp_string());
  fittingVec.clear();
  fittingVecTime.clear();
  activeSig = 1;
  holding = 0;
  refreshCount = 0;

  return 0;
}

int PolyFItMov::onEndTime(RangeStat &RangeData, RangeStat &lastRangeData) {
  flatAll(lastRangeData.code(), lastRangeData.close(),
          lastRangeData.end_timestamp_string());
  fittingVec.clear();
  fittingVecTime.clear();
  return 0;
}

int PolyFItMov::onRange(RangeStat &RangeData) {
  fittingVec.push_back(RangeData.close());
  fittingVecTime.push_back(RangeData.unix_timestamp());
  if (fittingVec.size() > WindowLength) {
    fittingVec.erase(fittingVec.begin());
    fittingVecTime.erase(fittingVecTime.begin());
  }
  //return 0;
//  LOG(INFO) << "timesig:" <<  RangeData.end_timestamp_string() << ",refresh count: " << refreshCount;
  refreshCount += 1;
  if (refreshCount >= Interval && fittingVec.size() >= WindowLength) {
    refreshCount = 0;

    if (fittingVec.size() < 10) {
      return 0;
    }


    LOG(INFO) << fittingVec.size() << ", time" << RangeData.end_timestamp_string();
    std::vector<double> X;
    for (unsigned i = 0; i < fittingVec.size(); i++) {
      X.push_back(i);
    }

    std::vector<double> der = getDerivatives(X, fittingVec, 3);
    std::vector<double> cof = polyFit(X, fittingVec, 3);
    if (stratDir == "POSITIVE") {

      onTriggerTime(der, cof, RangeData);
    } else if (stratDir == "NEGTIVE") {
      onTriggerTimeNeg(der, cof, RangeData);
    } else {
      LOG(FATAL) << "stat direction not known plz check!";
    }
  }
  return 0;
}


int PolyFItMov::onTrigger() {
  return 0;
}


////////////////////////////////////////////////////////////////////////////////


int PolyFItMov::onTriggerTimeNeg(std::vector<double> &der,
                                   std::vector<double> &cof,
                                   RangeStat &range) {


  std::string timeStr = unixTimeToStr(range.unix_timestamp());

  if (der[0] > 0 && der[1] > 0) {
    limitPositionAlg(1, SHORT_SELL,
                     range.code(), 1, range.close(),
                     timeStr);
    LOG(INFO) << "<<<{\"sell\":" << range.close() << "}>>>";
    LOG(INFO) << "trade day:" << timeStr << ", direction: SHORT";
    holding = -1;
  } else if (der[0] < 0 && der[1] < 0) {
    limitPositionAlg(1, LONG_BUY,
                     range.code(), 1, range.close(),
                     timeStr);
    LOG(INFO) << "<<<{\"long\":" << range.close() << "}>>>";
    LOG(INFO) << "trade day:" << timeStr << ", direction: LONG";
    holding = 1;
  } else {
    flatAll(range.code(), range.close(), range.end_timestamp_string());
  }

  return 0;
}

int PolyFItMov::onTriggerTime(std::vector<double> &der,
                                std::vector<double> &cof, RangeStat &range) {
  // for (auto iter = fittingVec.begin(); iter!=fittingVec.end();iter++) {
//		LOG(INFO) << "data:" << *iter;
  //}

  std::string timeStr = unixTimeToStr(range.unix_timestamp());

  if (der[0] > 0 && der[1] > 0) {
    LOG(INFO) << "LONG der0:" << der[0] << "," << ",der1:"
              << der[1];
    limitPositionAlg(1, LONG_BUY,
                     range.code(), 1, range.close(),
                     timeStr);
    LOG(INFO) << "<<<{\"buy\":" << range.close() << "}>>>";
    LOG(INFO) << "trade day:" << timeStr << ", direction: LONG";
    holding = 1;
  } else if (der[0] < 0 && der[1] < 0) {
    LOG(INFO) << "LONG der0:" << der[0] << "," << ",der1:"
              << der[1];
    limitPositionAlg(1, SHORT_SELL,
                     range.code(), 1, range.close(),
                     timeStr);
    LOG(INFO) << "<<<{\"sell\":" << range.close() << "}>>>";
    LOG(INFO) << "trade day:" << timeStr << ", direction: SHORT";
    holding = -1;
  }

  return 0;
}
