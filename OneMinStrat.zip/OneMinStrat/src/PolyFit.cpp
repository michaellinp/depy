#include <iostream>
#include <vector>
#include <gsl_multifit.h>


std::vector<double>
polyFit(std::vector<double> X, std::vector<double> y, unsigned int order) {
  std::vector<double> w;

  unsigned long xSize = X.size();
  unsigned long ySize = y.size();

  if (xSize != ySize) {
    return w;
  }

  gsl_matrix *xMatrix, *cov;
  gsl_vector *wVector, *yVector, *c;
  double chisq;

  xMatrix = gsl_matrix_alloc(xSize, order);
  yVector = gsl_vector_alloc(ySize);
  wVector = gsl_vector_alloc(xSize);

  cov = gsl_matrix_alloc(order, order);
  c = gsl_vector_alloc(order);

  for (unsigned i = 0; i < xSize; i++) {
    double xi = 1;
    for (unsigned j = 0; j < order; j++) {
      gsl_matrix_set(xMatrix, i, j, xi);
      xi = xi * X[i];
    }
  }

  for (unsigned i = 0; i < ySize; i++) {
    gsl_vector_set(yVector, i, y[i]);
    gsl_vector_set(wVector, i, 1);
  }

  gsl_multifit_linear_workspace *work
      = gsl_multifit_linear_alloc(xSize, order);

  gsl_multifit_wlinear(xMatrix, wVector, yVector, c, cov, &chisq, work);
  gsl_multifit_linear_free(work);

  for (unsigned i = 0; i < order; i++) {
    //std::cout << "parameters" << i << ":" << gsl_vector_get(c,(i)) << std::endl;
    w.push_back(gsl_vector_get(c, (i)));
  }
  return w;
}

std::vector<double> getDerivatives(std::vector<double> X, std::vector<double> y,
                                   unsigned int order) {
  std::vector<double> w = polyFit(X, y, order);

  std::vector<double> derivatives;
  double lastX = X[X.size()-1];
  derivatives.push_back(2*w[2]*lastX + w[1]);
  derivatives.push_back(2*w[2]);

/*  std::cout << "X size:" << X.size() << ", last X:" << lastX << std::endl;
  std::cout << "derivative2:" << derivatives[1] << std::endl;
  std::cout << "derivatives1:" << derivatives[0] << std::endl;*/

  return derivatives;
}
