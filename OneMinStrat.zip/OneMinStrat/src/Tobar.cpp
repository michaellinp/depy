#include "Tobar.h"

Tobar::Tobar() {
  initFlag = 0;
  seconds = 60;

  interval = pt::time_duration(0, 0, seconds);
  start = pt::time_from_string("1970-01-01 00:00:00.000");
  end = pt::time_from_string("1970-01-01 00:00:00.000");
}

Tobar::Tobar(int seconds) {
  initFlag = 0;

  interval = pt::time_duration(0, 0, seconds);
  start = pt::time_from_string("1970-01-01 00:00:00.000");
  end = pt::time_from_string("1970-01-01 00:00:00.000");
}

int Tobar::getTick(MarketUpdate &mkt, RangeStat &rangeST) {
  //LOG(INFO) << "enter";
  std::string timeBuf = "      ";
  std::sprintf(const_cast<char *>(timeBuf.c_str()), "%06ld",
               mkt.exchange_timestamp());
  pt::ptime mktPTime = CedarTimeHelper::unixTimestampToPTime(
      mkt.unix_timestamp());

  if (start == end) {
    //LOG(INFO) << "test1";
    pt::time_duration mktSeconds = pt::time_duration(0, 0, seconds);
    start = ripTimeResidualSec(mktPTime);
    end = start + interval;
    high = mkt.last_price();
    low = mkt.last_price();
    open = mkt.last_price();
    close = mkt.last_price();
  } else if (mktPTime > end || mktPTime < start) {
    //LOG(INFO) << "test2";
    pt::time_duration mktSeconds = pt::time_duration(0, 0, seconds);
/*    LOG(INFO) << mktPTime;
    LOG(INFO) << start;
    LOG(INFO) << end;
    LOG(INFO) << interval;*/
    start = ripTimeResidualSec(mktPTime);
    end = start + interval;
    rangeST.set_code(mkt.code());
    rangeST.set_open(open);
    rangeST.set_close(close);
    rangeST.set_high(high);
    rangeST.set_low(low);
    rangeST.set_volume(0);

    boost::posix_time::time_facet *tf = new boost::posix_time::time_facet(
        "%Y%m%d_%H:%M:%S");
    std::stringstream startStream;
    startStream.imbue(std::locale(std::cout.getloc(), tf));
    startStream << start;
    std::string startStr;
    startStream >> startStr;

    //LOG(INFO) << "test6";
    std::stringstream endStream;
    endStream.imbue(std::locale(std::cout.getloc(), tf));
    endStream << end;
    std::string endStr;
    startStream >> endStr;

    // LOG(INFO) << startStr;
    //  LOG(INFO) << end;
    //  LOG(INFO) << endStr;

    rangeST.set_unix_timestamp(CedarTimeHelper::ptimeToUnixTimestamp(end));
    rangeST.set_begin_timestamp_string(startStr);
    rangeST.set_begin_timestamp_string(endStr);

    high = mkt.last_price();
    low = mkt.last_price();
    open = mkt.last_price();
    close = mkt.last_price();
    //LOG(INFO) << "test7";
    return 1;
  } else {
    //LOG(INFO) << "test3";
    close = mkt.last_price();
    high = (mkt.last_price() > high) ? mkt.last_price() : high;
    low = (mkt.last_price() < low) ? mkt.last_price() : low;
  }
  //LOG(INFO) << "test4";
  return 0;
}

boost::posix_time::ptime
Tobar::ripTimeResidualSec(boost::posix_time::ptime time) {
  boost::posix_time::ptime target = boost::posix_time::from_iso_string(
      boost::posix_time::to_iso_string(time).substr(0, 13) + "00,000");
  return target;
}