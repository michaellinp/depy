#include "MinuteStrat.h"

MinuteStrat::MinuteStrat() {


  CedarJsonConfig::getInstance().getStringByPath("Strategy.Mode", mode);

  if (mode == "BACKTEST") {
    mode = "Backtest";
  } else if (mode == "LIVETEST") {
    mode = "Livetest";
  } else if (mode == "LIVE_TRADING") {
    mode = "LiveTrading";
  } else {
    LOG(FATAL) << "error with mode!";
  }


/*  std::vector<std::string> streams;
  if (mode == "Backtest") {
    CedarJsonConfig::getInstance().getStringArrayWithTag(streams, mode + "." +
                                                                  "Streams");
    if (streams.size() < 1) {
      LOG(FATAL) << "stream info missing plz check";
    } else {
      std::string streamName = streams[0];
      CedarJsonConfig::getInstance().getJsonValueByPath(mode + "." + streamName,
                                                        config);
    }
  } else if (mode == "Livetest") {
    CedarJsonConfig::getInstance().getJsonValueByPath(mode, config);
    config = config["DataRequest"][0];
  }*/

  CedarJsonConfig::getInstance().getJsonValueByPath("Parameters", config);

  oneMinData.init(config["Code"].asString(), 1 * 60);

  dayStartTimeStr = config["ActiveStart"].asString();
  dayEndTimeStr = config["ActiveEnd"].asString();

  respAddr = CedarHelper::getResponseAddr();


  activeSig = 1;
  triggerTimeStr = config["TriggerTime"].asString();
}

int MinuteStrat::onMsg(MessageBase &msg) {
//  LOG(INFO) << msg.type();
  if (msg.type() == TYPE_MARKETUPDATE) {

    MarketUpdate mktUpdt = ProtoBufHelper::unwrapMsg<MarketUpdate>(msg);
    if (mode != "Backtest" || mode != "BACKTEST") {
    //  LOG(INFO) << "tick:" << mktUpdt.DebugString();
    }

    RangeStat rangeStat;
    if (oneMinData.onTickUpdate(mktUpdt, rangeStat)) {
      rangeStat.set_stream("1minData");
      onRangeStatUpdate(rangeStat);
    }
  } else if (msg.type() == TYPE_RANGE_STAT) {
    RangeStat range = ProtoBufHelper::unwrapMsg<RangeStat>(msg);
    onRangeStatUpdate(range);
  }
  return 0;
}


int MinuteStrat::onCreate() {
  return true;
}

int MinuteStrat::onExit() {
/*  if (getStrategyMode() == BACKTEST) {
    transacLogger.saveToFile();
  }*/
  return true;
}

int MinuteStrat::onRangeStatUpdate(RangeStat &range) {
//   LOG(INFO) << "raNGE";

  if (DataHistory.size()>memoryLength) {
    DataHistory.erase(DataHistory.begin());
  }
  boost::posix_time::ptime currentTime = CedarTimeHelper::unixTimestampToPTime(
      range.unix_timestamp());

  boost::posix_time::ptime datePTime = getDayTimeFromRange(range);
  boost::posix_time::time_duration startDuration(
      boost::posix_time::duration_from_string(dayStartTimeStr));
  boost::posix_time::time_duration endDuration(
      boost::posix_time::duration_from_string(dayEndTimeStr));

  boost::posix_time::ptime dayStartTime =
      datePTime + startDuration;
  boost::posix_time::ptime dayEndTime =
      datePTime + endDuration;

  if (DataHistory.size() > 0) {
    RangeStat lastRangeData = DataHistory.back();
    boost::posix_time::ptime lastRangeTime =
        CedarTimeHelper::unixTimestampToPTime(lastRangeData.unix_timestamp());

    boost::posix_time::ptime lastDatePTime = getDayTimeFromRange(lastRangeData);

/*    LOG(INFO) << "currentTime:" << currentTime;
    LOG(INFO) << "lastRangeTime:" << lastRangeTime;
    LOG(INFO) << "lastDatePTime:" << lastDatePTime;
    LOG(INFO) << "lastRangeTime:" << lastRangeTime;
    LOG(INFO) << "dayEndTime:" << lastRangeTime;*/

    if (datePTime == lastDatePTime && lastRangeTime <= dayEndTime &&
        currentTime > dayEndTime) {
      onEndTime(range, lastRangeData);
    }

    if (currentTime.date() != lastRangeTime.date()) {
      onDayChange(range, lastRangeData);
    }
  }

  //LOG(INFO) << datePTime;

  if (currentTime >= dayStartTime && currentTime <= dayEndTime) {
  //if (true) {
    onRange(range);
    DataHistory.push_back(range);
    if (activeSig == 1) {
      if (DataHistory.size() > 1) {

        boost::posix_time::time_duration TriggerDuration(
            boost::posix_time::duration_from_string(triggerTimeStr));
        boost::posix_time::ptime triggerThreshold =
            datePTime + TriggerDuration;

        RangeStat lastRangeData = DataHistory.at(DataHistory.size() - 2);
        boost::posix_time::ptime lastRangeTime =
            CedarTimeHelper::unixTimestampToPTime(lastRangeData.unix_timestamp());

        if (lastRangeTime.date() == currentTime.date() &&
            lastRangeTime < triggerThreshold && currentTime >= triggerThreshold) {
          onTrigger();
        }
      }
    }
  } else {
    DataHistory.push_back(range);
  }

/*  if (DataHistory.size() > 0) {
    RangeStat lastRangeData = DataHistory.back();
    boost::posix_time::ptime lastRangeDataTime =
        CedarTimeHelper::unixTimestampToPTime(lastRangeData.unix_timestamp());
    boost::posix_time::ptime lastDatePTime = getDayTimeFromRange(range);

  }*/

  return 0;
}

std::string MinuteStrat::unixTimeToStr(unsigned long unix) {
  time_t tick = unix / 1000;
  struct tm tm;
  tm = *localtime(&tick);

  char s[50];
  strftime(s, sizeof(s), "%Y%m%d %H:%M:%S", &tm);

  std::string timeStr = s;

  return timeStr;
}

boost::posix_time::ptime
MinuteStrat::getDayTimeFromRange(RangeStat &range) {
  std::string rangeTimeStr = unixTimeToStr(range.unix_timestamp());
  std::string dayTimeStr =
      rangeTimeStr.substr(0, 4) + "-" + rangeTimeStr.substr(4, 2) +
      "-" +
      rangeTimeStr.substr(6, 2) + " 00:00:00.000";
  // LOG(INFO) << dayTimeStr;
  boost::posix_time::ptime dayTime(
      boost::posix_time::time_from_string(dayTimeStr));
  return dayTime;
}
