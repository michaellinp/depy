#include "CCIStrat.h"

CCIStrat::CCIStrat() : CCIIndicator(14) {
  stratDir = config["Direction"].asString();
}

int CCIStrat::onDayChange(RangeStat &RangeData, RangeStat &lastRangeData) {
  flatAll(lastRangeData.code(), lastRangeData.close(),
          lastRangeData.end_timestamp_string());
  fittingVec.clear();
  fittingVecTime.clear();
  activeSig = 1;
  holding = 0;
  return 0;
}

int CCIStrat::onEndTime(RangeStat &RangeData, RangeStat &lastRangeData) {
  flatAll(lastRangeData.code(), lastRangeData.close(),
          lastRangeData.end_timestamp_string());
  fittingVec.clear();
  fittingVecTime.clear();
  return 0;
}

int CCIStrat::onRange(RangeStat &RangeData) {
  double CCI;
  if (CCIIndicator.update(RangeData.high(), RangeData.low(),
                          RangeData.close(), CCI)) {
    if (CCI > 0) {
      limitPositionAlg(1, SHORT_SELL,
                       RangeData.code(), 1, RangeData.close(),
                       RangeData.end_timestamp_string());
    } else if (CCI < 0) {
      limitPositionAlg(1, LONG_BUY,
                       RangeData.code(), 1, RangeData.close(),
                       RangeData.end_timestamp_string());
    }
  }

  return 0;
}


int CCIStrat::onTrigger() {

  return 0;
}

