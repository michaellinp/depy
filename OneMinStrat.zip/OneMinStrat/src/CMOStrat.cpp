#include "CMOStrat.h"

CMOStrat::CMOStrat(): CMOIndicator(14) {
  stratDir = config["Direction"].asString();
}

int CMOStrat::onDayChange(RangeStat &RangeData, RangeStat &lastRangeData) {
  flatAll(lastRangeData.code(), lastRangeData.close(),
          lastRangeData.end_timestamp_string());
  fittingVec.clear();
  fittingVecTime.clear();
  activeSig = 1;
  holding = 0;
  return 0;
}

int CMOStrat::onEndTime(RangeStat &RangeData, RangeStat &lastRangeData) {
  flatAll(lastRangeData.code(), lastRangeData.close(),
          lastRangeData.end_timestamp_string());
  fittingVec.clear();
  fittingVecTime.clear();
  return 0;
}

int CMOStrat::onRange(RangeStat &RangeData) {
  double cmo;
  if (CMOIndicator.update(RangeData.close(), cmo)) {
    if (cmo>0) {
      limitPositionAlg(1, LONG_BUY,
                       RangeData.code(), 1, RangeData.close(),
                       RangeData.end_timestamp_string());
    } else if (cmo<0) {
      limitPositionAlg(1, SHORT_SELL,
                       RangeData.code(), 1, RangeData.close(),
                       RangeData.end_timestamp_string());
    }
  }

  return 0;
}


int CMOStrat::onTrigger() {

  return 0;
}

