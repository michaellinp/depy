#include "CMOStrat.h"
#include "CedarHelper.h"

int main(int argc, char *argv[]) {
  CedarHelper::cedarAppInit(argc, argv);

  CMOStrat pfs;
  pfs.run();


  google::protobuf::ShutdownProtobufLibrary();

}